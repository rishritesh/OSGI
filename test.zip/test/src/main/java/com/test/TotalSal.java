package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TotalSal {
	private static final Logger l = Logger.getLogger(TotalSal.class.getName());

	public static void collect() {
		try {
		    FileInputStream inputStream = new FileInputStream("/home/noida/Desktop/xl_file/data/cal.xlsx");
		    Workbook workbook = new XSSFWorkbook(inputStream);
		    Sheet sheet = workbook.getSheetAt(0); // Assuming data is in the first sheet

		    FileInputStream appendStream = new FileInputStream("/home/noida/Desktop/xl_file/data/caloutput1.xlsx");
		    Workbook appendWorkbook = new XSSFWorkbook(appendStream);
		    Sheet appendSheet = appendWorkbook.getSheetAt(0); // Assuming data is in the first sheet

		    int rowCount = Math.max(sheet.getPhysicalNumberOfRows(), appendSheet.getPhysicalNumberOfRows());
		    int finalAmount=0;
		    for (int i = 1; i < rowCount; i++) {
		        Row existingRow = sheet.getRow(i);
		        Row appendRow = appendSheet.getRow(i);
		        Cell id = appendRow.getCell(44);
		        

		        if (existingRow == null) {
		            existingRow = sheet.createRow(i);
		        }
		        

		        int startColumn = existingRow.getLastCellNum() >= 0 ? existingRow.getLastCellNum() : 0;
		        

		        if (appendRow != null) {
		            int columnCount = appendRow.getPhysicalNumberOfCells();
		            for (int j = 0; j < columnCount; j++) {
		                Cell cell = appendRow.getCell(j);
		                Cell existingCell = existingRow.createCell(startColumn + j);
//		                System.out.println(i+"inside column");

		                if (cell != null) {
		                    switch (cell.getCellType()) {
		                        case STRING:
		                            existingCell.setCellValue(cell.getStringCellValue());
		                            break;
		                        case NUMERIC:
		                            if (DateUtil.isCellDateFormatted(cell)) {
//		                            	System.out.println(cell.getNumericCellValue()+"date ");	
		                                existingCell.setCellValue(cell.getDateCellValue());
		                                
//		                                existingCell.setCellValue(cell.getDateCellValue());
		                                // Set the cell format to a date format
		                                CellStyle dateCellStyle = existingCell.getCellStyle();
		                                CreationHelper createHelper = existingCell.getSheet().getWorkbook().getCreationHelper();
		                                dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/MM/yyyy")); // You can change the date format as per your requirement
		                                existingCell.setCellStyle(dateCellStyle);
//		                                System.out.println(dateCellStyle);
		                            } else {
		                                existingCell.setCellValue(cell.getNumericCellValue());
		                            }
		                            break;
		                        case BOOLEAN:
		                            existingCell.setCellValue(cell.getBooleanCellValue());
		                            break;
		                        case FORMULA:
		                            switch (cell.getCachedFormulaResultType()) {
		                                case STRING:
		                                    existingCell.setCellValue(cell.getStringCellValue());
		                                    break;
		                                case NUMERIC:
//		                                	System.out.println(cell.getNumericCellValue()+"inside formula");
//		                                	System.out.println(cell.getNumericCellValue());
//		                                	finalAmount=(int) +cell.getNumericCellValue();
//		                                	System.out.println(finalAmount+"final ");

		                                    existingCell.setCellValue(cell.getNumericCellValue());
		                                    break;
		                                case BOOLEAN:
		                                    existingCell.setCellValue(cell.getBooleanCellValue());
		                                    break;
		                            }
		                            break;
		                        default:
		                            existingCell.setCellValue("");
		                    }
		                }
		            }
		        }
		    }

		    FileOutputStream outputStream = new FileOutputStream("/home/noida/Desktop/xl_file/data/cal1.xlsx");
		    workbook.write(outputStream);

		    outputStream.flush();
		    outputStream.close();
		    workbook.close();
		    inputStream.close();

		    //System.out.println("Data merged successfully.");
		    l.info("Data merged successfully.");
		} catch (Exception e) {
		    e.printStackTrace();
		}

	}
	


}
