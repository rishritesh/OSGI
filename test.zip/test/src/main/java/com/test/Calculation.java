package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.data.Emp;
import com.data.EmpSal;


public class Calculation {
	private static final Logger l = Logger.getLogger(Calculation.class.getName());
	
	public static void main(String[] args) {
		
		try {
            // Provide the path to your Excel file
            FileInputStream file = new FileInputStream(new File("/home/noida/Desktop/xl_file/data/salary.xlsx"));
//            FileInputStream file1 = new FileInputStream(new File("/home/noida/Desktop/xl_file/data/cal.xlsx"));

            // Create Workbook instance for XLSX file
            Workbook workbook = new XSSFWorkbook(file);
//            Workbook workbook1 = new XSSFWorkbook(file1);

            // Get the first sheet in the workbook
            Sheet sheet = workbook.getSheetAt(0);
//            Sheet sheet1 = workbook1.getSheetAt(0);

            // Map to store employee ID and corresponding payable days
            Map<Long, Emp> employeePayableDays = new LinkedHashMap<>();
          //  Map<Long, EmpSal> employeePayableDays1 = new LinkedHashMap<>();
            
            

            for (int i = 2; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                Cell name=row.getCell(0);
                Cell idCell = row.getCell(1); // Assuming Employee ID is in the first column
                Cell daysCell = row.getCell(11); // Assuming Payable Days is in the second column
                Cell days=row.getCell(2);
//                System.out.println(days);
                
                
                if (idCell != null && daysCell != null) {
                    Long employeeId = (long) idCell.getNumericCellValue();
//                    System.out.println(employeeId);
                    int day= (int)days.getNumericCellValue();
                    
                    String EmpName=name.getStringCellValue();
                   
                    int payableDays = 0;

                    try {
                   
                       payableDays = (int) (daysCell.getNumericCellValue());
//                       System.out.println(payableDays);
                       
                    }catch(Exception e) {
                    	e.printStackTrace();
                    }
                       
                       
                       

                   
                    employeePayableDays.put(employeeId, new Emp(EmpName,day,payableDays-day,payableDays));
                    
                }
            }

            // Perform calculation for each employee
            for (Map.Entry<Long, Emp> entry : employeePayableDays.entrySet()) {
                Long employeeId = entry.getKey();
                Emp payableDays = entry.getValue();
            }
//            System.out.println(employeePayableDays);
            
            
            
            write(employeePayableDays);
            

            // Close the workbook and file input stream
            workbook.close();
            file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
        //calling calculation
		TotalSal.collect();
		Salary.salary();
	}
	
	public static void write(Map<Long,Emp> employeePayable) {
		 // Create a new workbook
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Data");
            
            
            Row headerRow = sheet.createRow(1);
            headerRow.createCell(0).setCellValue("EmpCode");
            headerRow.createCell(1).setCellValue("EmpName");
            headerRow.createCell(2).setCellValue("MonthDays");
            headerRow.createCell(3).setCellValue("BalanceDays");
            headerRow.createCell(4).setCellValue("TotalAttendance");
            headerRow.createCell(5).setCellValue("DaysAmoutPay");
            
            
            
            

            // Write data from map to Excel
            int rowNum = 2;
            for (Map.Entry<Long, Emp> entry : employeePayable.entrySet()) {
                Row row = sheet.createRow(rowNum++);
                
                
                row.createCell(0).setCellValue(entry.getKey()); // Assuming key is to be written in first column
//                row.createCell(1).setCellValue(String.valueOf(entry.getValue()));// Assuming value is to be written in second column
                
                
                Emp emp = entry.getValue();
               
//                row.createCell(0).setCellValue(entry.getKey()); // ID in first column

                // Set other fields of Emp in subsequent columns
                row.createCell(1).setCellValue(emp.getName());
                row.createCell(2).setCellValue(emp.getDays());
               row.createCell(3).setCellValue(emp.getPayableDays());
               row.createCell(4).setCellValue(emp.getTotalAttendance());
               
               
               Cell month=row.getCell(2);
               Cell day1=row.getCell(4);
               int data=(int)day1.getNumericCellValue();
              int days=(int)month.getNumericCellValue();
              
              boolean val=data>days;
              if(data>days) {
            	  row.createCell(5).setCellValue(days);
              }
              else {
            	  row.createCell(5).setCellValue(data);
              }
               
            }

            // Write workbook content to file
            try (FileOutputStream outputStream = new FileOutputStream("/home/noida/Desktop/xl_file/data/cal.xlsx")) {
                workbook.write(outputStream);
            }

           // System.out.println("Excel file has been created successfully.");
            l.info("Excel file has been created successfully.");
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
	}
	
	
	

}
