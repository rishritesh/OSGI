package com.hotRod;

import java.io.IOException;
import java.util.logging.Logger;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

public class Mycall implements CallbackHandler {
	
	private static final Logger L = Logger.getLogger(Mycall.class.getName());
	
		private String username = "admin";
	    private String password="admin";
	    
	    
	    

	public Mycall(String username, String password) {
			super();
			this.username = username;
			this.password = password;
		}

	


	@Override
    public void handle(Callback[] callbacks) throws UnsupportedCallbackException {
		L.info("working in call back");
        for (Callback callback : callbacks) {
            if (callback instanceof NameCallback) {
                // Handle username callback
                NameCallback nameCallback = (NameCallback) callback;
                // Set the username (e.g., "admin")
                nameCallback.setName(username);
            } else if (callback instanceof PasswordCallback) {
                // Handle password callback
                PasswordCallback passwordCallback = (PasswordCallback) callback;
                // Set the password (e.g., "password")
                passwordCallback.setPassword(password.toCharArray());
            } else {
                throw new UnsupportedCallbackException(callback, "Callback not supported");
            }
        }
    }

}
